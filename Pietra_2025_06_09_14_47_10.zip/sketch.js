let plantas = [];
let colhidas = 0;
let saquinhos = 0;
let score = 0;

function setup() {
  let canvas = createCanvas(600, 400);
  canvas.parent("canvas-container");
}

function draw() {
  background("#fffde7");

  fill("#33691e");
  textSize(16);
  text(`Frutas colhidas: ${colhidas}`, 10, 20);
  text(`Saquinhos prontos: ${saquinhos}`, 10, 40);
  text(`Use A (Plantar), W (Colher), S (Empacotar), D (Vender)`, 10, height - 10);

  for (let i = 0; i < plantas.length; i++) {
    plantas[i].mostrar();
    plantas[i].crescer();
  }
}

// Classe das plantas
class Planta {
  constructor() {
    this.x = random(50, width - 50);
    this.y = random(100, height - 100);
    this.estado = 0; // 0 = semente, 1 = crescendo, 2 = madura
    this.timer = 0;
    this.emoji = random(["🍎", "🍊", "🍓", "🍌"]);
  }

  crescer() {
    this.timer++;
    if (this.timer > 180) {
      this.estado = 2;
    } else if (this.timer > 90) {
      this.estado = 1;
    }
  }

  mostrar() {
    textSize(32);
    if (this.estado === 0) {
      text("🌱", this.x, this.y);
    } else if (this.estado === 1) {
      text("🌿", this.x, this.y);
    } else {
      text(this.emoji, this.x, this.y);
    }
  }
}

// Plantar
function keyPressed() {
  if (key === 'a' || key === 'A') {
    plantas.push(new Planta());
  }

  // Colher frutas maduras
  if (key === 'w' || key === 'W') {
    for (let i = plantas.length - 1; i >= 0; i--) {
      if (plantas[i].estado === 2) {
        plantas.splice(i, 1);
        colhidas++;
        break;
      }
    }
  }

  // Empacotar
  if (key === 's' || key === 'S') {
    if (colhidas > 0) {
      colhidas--;
      saquinhos++;
    }
  }

  // Vender
  if (key === 'd' || key === 'D') {
    if (saquinhos > 0) {
      saquinhos--;
      score += 10;
      document.getElementById("score").textContent = score;
    }
  }
}